from django.contrib import admin
from .models import Customuser

# Register your models here.

# admin.site.register(CustomUser)
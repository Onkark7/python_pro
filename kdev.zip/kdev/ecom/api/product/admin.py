from django.contrib import admin
from .models import product
# Register your models here.

admin.site.register(product)
